# Student Information

**Course:** COSC1125/1127 Artificial Intelligence

**Semester:** Semester 2, 2023

**Instructor:** Prof. Sebastian Sardina

**Team name:** INDIVIDUAL ASSESSMENT

**Team members:**

* Student's student number - Full Name - RMIT Student email - Student Github username

Student numbers should just be the **numbers**.
